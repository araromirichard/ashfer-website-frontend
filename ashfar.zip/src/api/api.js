import axios from "axios";

export default axios.create({
    baseURL: "http://ashfar-api.test/api/",
});