<template>
  <div class="pt-0 md:pt-[140px]">
    <div class="relative z-0 h-40 md:h-96 w-full">
      <img
        src="/images/csrHero.jpg"
        alt="our business"
        class="w-full h-full object-cover"
      />
      <div class="absolute inset-0 bg-[#f15a29] opacity-10"></div>
      <div class="absolute inset-0">
        <div
          class="container mx-auto w-full h-full flex items-center justify-start px-8 sm:px-0 sm:justify-start text-white text-lg md:text-[54px] md:leading-relaxed font-bold font-poppins capitalize"
        >
          Our Rural Electrification <br />
          initiatives
        </div>
      </div>
    </div>
    <div
      class="container mx-auto w-full grid grid-cols-1 md:grid-cols-2 gap-0 md:gap-20 justify-center content-center py-10 md:py-14 px-8 md:px-0"
    >
      <div
        class="space-y-6 py-20 font-poppins font-normal text-sm md:text-lg text-blacky text-left md:text-justify"
      >
        <p>
          We are committed to not just providing quality services to our
          clients. We are also dedicated to impacting rural communities in Ghana
          where universal access to electricity have not been realized.
        </p>
        <p>
          We are passionate about improving healthcare service delivery in rural
          communities through the provision of affordable clean energy. We are
          currently ruuning this program in the Wa West District Assembly (Wa
          West) of the Upper West region of Ghana.
        </p>
        <p>
          We believe that by electrifying primary healthcare centers in Wa West,
          we will achieve an outcome of better healthcare services as a result
          of the improved capacity to refrigerate and store essential medical
          supplies with the aim of achieving SDG3 in the community.
        </p>
      </div>
      <div class="space-y-4">
        <img src="/images/CSR-PAGE-2.jpg" alt="" />
        <img src="/images/CSR-PAGE.jpg" alt="" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    return {};
  },
};
</script>
<style scoped></style>
